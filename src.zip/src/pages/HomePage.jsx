import React from 'react';
import { Link } from 'react-router-dom';

const FeatureCard = ({ icon, title, description }) => (
  <div className="bg-white/80 backdrop-blur-sm p-8 rounded-xl shadow-lg text-center transition-all duration-300 hover:shadow-2xl hover:-translate-y-2">
    <div className="text-4xl mb-4 text-green-700">{icon}</div>
    <h3 className="text-xl font-bold text-gray-800 mb-2">{title}</h3>
    <p className="text-gray-600">{description}</p>
  </div>
);

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-100 via-teal-100 to-green-200 text-gray-800">
      <nav className="p-6 flex justify-between items-center">
        <h1 className="text-2xl font-bold flex items-center">
          <span className="text-3xl mr-2">🌿</span> AI Crop Disease Tracker
        </h1>
        <div>
          <Link to="/dashboard" className="font-semibold text-gray-600 hover:text-green-700 mr-6">Dashboard</Link>
          <Link to="/tracker" className="font-semibold text-gray-600 hover:text-green-700">Tracker</Link>
        </div>
      </nav>

      <main className="container mx-auto px-6 py-24 text-center">
        <h2 className="text-5xl md:text-6xl font-extrabold leading-tight mb-4">
          AI-Powered Crop Disease Detection
        </h2>
        <p className="text-lg text-gray-600 max-w-3xl mx-auto mb-10">
          Upload plant leaf images and get instant AI-powered disease identification with confidence scores, risk assessments, and interactive mapping of affected areas.
        </p>
        <Link to="/dashboard" className="bg-green-600 text-white font-bold py-4 px-8 rounded-lg shadow-lg hover:bg-green-700 transition-all duration-300 transform hover:scale-105">
          Get Started →
        </Link>
        
        <div className="grid md:grid-cols-3 gap-8 mt-24">
          <FeatureCard icon="📸" title="Image Analysis" description="Upload leaf images for instant AI-powered disease detection." />
          <FeatureCard icon="📍" title="GPS Tracking" description="Automatically capture location data for disease mapping." />
          <FeatureCard icon="☣️" title="Risk Assessment" description="Get detailed risk levels and confidence scores for your crops." />
        </div>
      </main>
    </div>
  );
}