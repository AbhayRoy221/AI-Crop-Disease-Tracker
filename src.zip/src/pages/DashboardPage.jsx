import React, { useState, useEffect } from 'react';
import axios from 'axios';
import MapView from '../components/MapView';
import ReportsTable from '../components/ReportsTable';
import AnalyticsCharts from '../components/AnalyticsCharts';
import Header from '../components/Header';
import DemoReports from '../demo-reports.json';

const StatCard = ({ value, label, isHighlighted = false }) => (
  <div className={`p-5 rounded-xl shadow-md transition-all duration-300 hover:shadow-lg hover:-translate-y-1 ${
    isHighlighted ? 'bg-green-600 text-white' : 'bg-white'
  }`}>
    <p className={`text-3xl font-bold ${isHighlighted ? 'text-white' : 'text-gray-800'}`}>{value}</p>
    <p className={`text-sm font-semibold mt-1 ${isHighlighted ? 'text-green-100' : 'text-gray-500'}`}>{label}</p>
  </div>
);

export default function DashboardPage() {
  const [reports, setReports] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchReports = async () => {
      try {
        const response = await axios.get('http://127.0.0.1:8000/reports');
        setReports(response.data.filter(r => r.lat && r.lon));
      } catch (err) {
        setError('Could not connect to the backend. Displaying demo data.');
        setReports(DemoReports.filter(r => r.lat && r.lon));
      }
    };
    fetchReports();
  }, []);

  const mostCommonDisease = () => {
    if (reports.length === 0) return "N/A";
    const freq = reports.reduce((acc, r) => { (acc[r.disease] = (acc[r.disease] || 0) + 1); return acc; }, {});
    return Object.keys(freq).reduce((a, b) => freq[a] > freq[b] ? a : b).replace(/_/g, ' ');
  };

  const highRiskLevel = reports.some(r => r.risk_level === "High") ? "High" : reports.some(r => r.risk_level === "Medium") ? "Medium" : "Low";
  const uniqueRegions = new Set(reports.map(r => `${r.lat.toFixed(2)},${r.lon.toFixed(2)}`)).size;

  return (
    <div className="flex-1 bg-gray-50 overflow-y-auto">
      <Header title="Dashboard" subtitle="Real-time overview of crop health and disease outbreaks" />
      <div className="p-6">
        {error && (
          <div className="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4 mb-6 rounded-md" role="alert">
            <p className="font-bold">Warning:</p><p>{error}</p>
          </div>
        )}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
          <StatCard value={reports.length} label="Total Reports" />
          <StatCard value={highRiskLevel} label="Highest Risk Area" isHighlighted={highRiskLevel === 'High'} />
          <StatCard value={mostCommonDisease()} label="Most Common" />
          <StatCard value={uniqueRegions} label="Regions Affected" />
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 bg-white p-2 rounded-xl shadow-md">
            <MapView reports={reports} viewMode="points" />
          </div>
          <div className="space-y-6">
            <ReportsTable reports={reports} />
            <AnalyticsCharts reports={reports} />
          </div>
        </div>
      </div>
    </div>
  );
}