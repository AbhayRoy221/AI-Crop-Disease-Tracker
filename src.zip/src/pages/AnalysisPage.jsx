import React from 'react';
import Header from '../components/Header';

// The base URL of your backend server
const BACKEND_URL = 'http://127.0.0.1:8000';

const ResultCard = ({ title, value, colorClass }) => (
  <div className="bg-gray-50 rounded-lg p-4 text-center">
    <p className="text-sm text-gray-500 font-medium">{title}</p>
    <p className={`text-2xl font-bold ${colorClass || 'text-gray-800'}`}>{value}</p>
  </div>
);

export default function AnalysisPage({ result, onReset }) {
  if (!result) return null;

  // This is the fix: We create the full URL for the browser to use.
  const imageUrl = `${BACKEND_URL}/${result.image_url.replace(/\\/g, '/')}`;
  const heatmapUrl = `${BACKEND_URL}/${result.heatmap_url.replace(/\\/g, '/')}`;

  const riskColor = {
    High: 'text-red-500',
    Medium: 'text-yellow-500',
    Low: 'text-green-500',
  }[result.risk_level];

  return (
    <div className="flex-1 bg-gray-50 overflow-y-auto">
      <Header title="Analysis Complete" subtitle="Here are the results from the AI model." />
      <div className="p-6">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
          {/* Left Column for Images */}
          <div className="lg:col-span-3 space-y-6">
            <div className="bg-white p-4 rounded-xl shadow-md">
              <h3 className="font-bold text-lg mb-4 text-center">Original Image</h3>
              <img src={imageUrl} alt="Original plant leaf" className="rounded-lg mx-auto w-full max-w-md" />
            </div>
            <div className="bg-white p-4 rounded-xl shadow-md">
              <h3 className="font-bold text-lg mb-4 text-center">AI Heatmap Analysis (Grad-CAM)</h3>
              <img src={heatmapUrl} alt="AI heatmap analysis" className="rounded-lg mx-auto w-full max-w-md" />
            </div>
          </div>

          {/* Right Column for Results */}
          <div className="lg:col-span-2">
            <div className="bg-white p-6 rounded-xl shadow-md sticky top-6">
              <h3 className="text-2xl font-bold text-gray-800 mb-4">Analysis Result</h3>
              <div className="grid grid-cols-2 gap-4 mb-6">
                <ResultCard title="Confidence" value={`${(result.confidence * 100).toFixed(1)}%`} />
                <ResultCard title="Risk Level" value={result.risk_level} colorClass={riskColor} />
              </div>
              <div className="mb-6">
                <p className="text-sm text-gray-500 font-medium">Predicted Disease</p>
                <p className="text-2xl font-bold text-blue-600">{result.disease.replace(/_/g, ' ')}</p>
              </div>
              <div className="mb-6">
                <h4 className="font-bold text-lg mb-2">Recommended Actions:</h4>
                <ul className="list-disc list-inside text-gray-700 space-y-1">
                  <li>Remove and destroy infected plants immediately.</li>
                  <li>Apply preventative fungicides before symptoms appear.</li>
                  <li>Avoid overhead watering; use drip irrigation.</li>
                  <li>Consult a local agricultural extension office for confirmation.</li>
                </ul>
              </div>
              <button
                onClick={onReset}
                className="w-full bg-green-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-green-700 transition-colors"
              >
                Analyze Another Image
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}