import React, { useState } from 'react';
import UploadForm from '../components/UploadForm';
import AnalysisPage from './AnalysisPage';
import Header from '../components/Header';
import AnalysisLoader from '../components/AnalysisLoader'; // Import the new loader

export default function TrackerPage() {
  const [status, setStatus] = useState('upload'); // 'upload', 'analyzing', 'result'
  const [analysisResult, setAnalysisResult] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);
  const [error, setError] = useState('');

  const handleAnalysisStart = (file) => {
    setImagePreview(URL.createObjectURL(file));
    setStatus('analyzing');
    setError('');
  };

  const handleAnalysisComplete = (result) => {
    setAnalysisResult(result);
    setStatus('result');
  };

  const handleError = (msg) => {
    setError(msg);
    setStatus('upload');
  };

  const handleReset = () => {
    setAnalysisResult(null);
    setImagePreview(null);
    setStatus('upload');
    setError('');
  };

  if (status === 'result') {
    return <AnalysisPage result={analysisResult} onReset={handleReset} />;
  }

  return (
    <div className="flex flex-col h-full">
      <Header 
        title={status === 'upload' ? "New Analysis" : "Analysis in Progress"} 
        subtitle="Upload an image to get a live diagnosis from our AI model"
      />
      <div className="flex-1 flex flex-col items-center justify-center p-6 bg-gray-50">
        {status === 'upload' && (
          <UploadForm
            onAnalysisComplete={handleAnalysisComplete}
            onAnalysisStart={handleAnalysisStart}
            onError={handleError}
          />
        )}
        {status === 'analyzing' && <AnalysisLoader imagePreview={imagePreview} />}
        {error && <p className="text-center text-red-500 p-4 mt-4 font-bold bg-red-100 rounded-lg">{error}</p>}
      </div>
    </div>
  );
}