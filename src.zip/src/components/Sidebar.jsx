import React from 'react';
import { NavLink } from 'react-router-dom';

export default function Sidebar() {
  const navItems = [
    { to: "/dashboard", icon: "📊", label: "Dashboard" },
    { to: "/tracker", icon: "🔬", label: "New Analysis" },
  ];
  const linkClasses = "w-full flex items-center px-4 py-3 rounded-xl text-left text-gray-200 transition-all duration-300 hover:bg-green-700/50";
  const activeLinkClasses = "bg-green-600 shadow-lg text-white font-bold";

  return (
    <div className="w-64 bg-gradient-to-b from-green-800 to-green-900 text-white flex flex-col shadow-2xl flex-shrink-0">
      <div className="p-6 border-b border-green-700/50">
        <div className="flex items-center">
          <div className="w-10 h-10 bg-green-400 rounded-lg flex items-center justify-center mr-3">
            <span className="text-green-900 font-black text-lg">🌿</span>
          </div>
          <span className="text-xl font-black tracking-wider">Vortexa</span>
        </div>
      </div>
      <nav className="flex-1 p-4">
        <div className="space-y-2">
          {navItems.map((item) => (
            <NavLink
              key={item.label}
              to={item.to}
              className={({ isActive }) => isActive ? `${linkClasses} ${activeLinkClasses}` : linkClasses}
            >
              <span className="text-xl mr-3">{item.icon}</span>
              <span className="font-semibold">{item.label}</span>
            </NavLink>
          ))}
        </div>
      </nav>
    </div>
  );
}