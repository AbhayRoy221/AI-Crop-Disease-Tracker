import React from 'react';

export default function ReportsTable({ reports }) {
  // To ensure we don't modify the original data, we create a sorted copy
  // This sorts the reports to show the newest ones first
  const sortedReports = [...reports].sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

  // A helper function to get the correct Tailwind CSS classes for the risk level
  const getRiskChipStyles = (riskLevel) => {
    switch (riskLevel) {
      case 'High':
        return 'bg-red-100 text-red-700';
      case 'Medium':
        return 'bg-yellow-100 text-yellow-700';
      case 'Low':
      default:
        return 'bg-green-100 text-green-700';
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-md overflow-hidden">
      <div className="p-4 border-b border-gray-200">
        <h3 className="text-lg font-bold text-gray-800">Recent Reports</h3>
      </div>
      <div className="overflow-y-auto max-h-64">
        {sortedReports.length > 0 ? (
          <table className="w-full text-sm text-left">
            <thead className="text-xs text-gray-500 uppercase bg-gray-50 sticky top-0">
              <tr>
                <th scope="col" className="px-4 py-2">Date</th>
                <th scope="col" className="px-4 py-2">Disease</th>
                <th scope="col" className="px-4 py-2">Risk</th>
                <th scope="col" className="px-4 py-2">TEST</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {/* We only show the top 10 most recent reports to keep the list clean */}
              {sortedReports.slice(0, 10).map((report) => (
                <tr key={report.id} className="hover:bg-gray-50">
                  <td className="px-4 py-3 text-gray-500 whitespace-nowrap">
                    {/* This code safely formats the date, showing 'N/A' if the timestamp is missing */}
                    {report.timestamp ? new Date(report.timestamp).toLocaleDateString() : 'N/A'}
                  </td>
                  <td className="px-4 py-3 font-medium text-gray-800">
                    {report.disease.replace(/_/g, ' ')}
                  </td>
                  <td className="px-4 py-3">
                    <span className={`px-2 py-1 rounded-full text-xs font-semibold ${getRiskChipStyles(report.risk_level)}`}>
                      {report.risk_level}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          // This message is shown if the 'reports' array is empty
          <p className="p-4 text-center text-gray-500">No reports found.</p>
        )}
      </div>
    </div>
  );
}