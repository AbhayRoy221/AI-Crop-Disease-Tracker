import React, { useState, useEffect } from 'react';

const statuses = [
  "Uploading image...",
  "Preprocessing...",
  "Running AI model...",
  "Generating heatmap...",
  "Finalizing results..."
];

export default function AnalysisLoader({ imagePreview }) {
  const [statusIndex, setStatusIndex] = useState(0);

  useEffect(() => {
    // Cycle through the status messages every 1.5 seconds
    const interval = setInterval(() => {
      setStatusIndex((prevIndex) => (prevIndex + 1) % statuses.length);
    }, 1500);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="text-center">
      <div className="relative inline-block rounded-2xl shadow-2xl overflow-hidden mb-6">
        <img src={imagePreview} alt="Analysis in progress" className="w-80 h-80 object-cover" />
        <div className="absolute inset-0 bg-black/20"></div>
        {/* The Scanline */}
        <div className="scanline absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-transparent via-green-300 to-transparent"></div>
      </div>
      <h2 className="text-2xl font-bold text-gray-800">Analyzing</h2>
      <p className="text-gray-500 mt-2 transition-all duration-300">{statuses[statusIndex]}</p>
    </div>
  );
}